import random

# Number of jobs
n = 10

# Generate random processing times
processing_times = [random.randint(1, 10) for _ in range(n)]

# Generate random release dates
release_dates = [random.randint(0, 10) for _ in range(n)]

# Generate random due dates
due_dates = [random.randint(10, 20) for _ in range(n)]

#EDD solution is to use a "look-ahead" approach, where you consider the effect of processing a job on the lateness of future jobs.
#1-Sort the jobs by due date as in the basic EDD algorithm
#2-Calculate the lateness of each job if it were to be processed immediately
#3-Select the job that results in the minimum overall lateness
#This approach can help to reduce the maximum lateness by taking into account the interactions between different jobs.

# Sort the jobs by due date
jobs = sorted(zip(processing_times, release_dates, due_dates), key=lambda x: x[2])

# Initialize the completion time of each job to its release date
completion_times = release_dates

# Initialize the current time to the maximum release date
current_time = max(release_dates)

# Initialize an empty list to store the lateness of each job
lateness = []

# Iterate over the jobs
for processing_time, release_date, due_date in jobs:
    # Calculate the lateness if the job is processed immediately
    immediate_lateness = current_time + processing_time - due_date
    
    # If the job is available at the current time, process it
    if release_date <= current_time:
        # Calculate the lateness of future jobs if the current job is processed immediately
        future_lateness = []
        for _, _, d in jobs[jobs.index((processing_time, release_date, due_date)) + 1:]:
            future_lateness.append(max(immediate_lateness, current_time + processing_time - d))
        
        # If the current job results in the minimum overall lateness, process it
        if immediate_lateness + sum(future_lateness) == min([current_time + pt - d for pt, _, d in jobs[jobs.index((processing_time, release_date, due_date)):]]):
            current_time += processing_time
            completion_times.append(current_time)
            lateness.append(current_time - due_date)
    
    # If the job is not available at the current time, wait until it becomes available
    else:
        current_time = release_date + processing_time
        completion_times.append(current_time)
        lateness.append(current_time - due_date)

# Calculate the maximum lateness
maximum_lateness = max(lateness)

print("maximum lateness:" , maximum_lateness)
print("processing_time:", processing_times)
print("release_dates" ,release_dates)
print("due_dates:" , due_dates)
print("lateness:",lateness)
print("completion_times:",completion_times)