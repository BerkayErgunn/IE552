import random

# Number of jobs
n = 10

# Generate random processing times
processing_times = [random.randint(1, 10) for _ in range(n)]

# Generate random release dates
release_dates = [random.randint(0, 10) for _ in range(n)]

# Generate random due dates
due_dates = [random.randint(10, 20) for _ in range(n)]

#One potential improvement heuristic for the EDD solution is to consider the processing times of the jobs in addition to the due dates. 
# This can be done by sorting the jobs by a priority value that takes both the due date and processing time into account.

# Initialize the completion time of each job to its release date
completion_times = release_dates

# Initialize the current time to the maximum release date
current_time = max(release_dates)

# Initialize an empty list to store the lateness of each job
lateness = []

# Sort the jobs by due date
jobs = sorted(zip(processing_times, release_dates, due_dates), key=lambda x: x[2])

# Iterate over the jobs
for processing_time, release_date, due_date in jobs:
    # If the job is available at the current time, process it
    if release_date <= current_time:
        current_time += processing_time
        completion_times.append(current_time)
        lateness.append(current_time - due_date)
    # If the job is not available at the current time, wait until it becomes available
    else:
        current_time = release_date + processing_time
        completion_times.append(current_time)
        lateness.append(current_time - due_date)

# Calculate the maximum lateness
maximum_lateness = max(lateness)

print("maximum lateness:" , maximum_lateness)
print("processing_time:", processing_times)
print("release_dates" ,release_dates)
print("due_dates:" , due_dates)
print("lateness:",lateness)
print("completion_times:",completion_times)